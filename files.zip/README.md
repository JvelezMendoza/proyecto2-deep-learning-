# 🏥 Diabetic Retinopathy Detection using Deep Learning

**Universidad Militar Nueva Granada – Facultad de Ingeniería**  
**Curso:** Deep Learning  
**Profesor:** Diego Renza Torres  
**Fecha:** Abril 2026

## 👥 Equipo
- Luis Carlos Velandia Cuevas
- Juan Esteban Velez
- Juan Cumbe

---

## 📋 Descripción

Proyecto de clasificación de retinopatía diabética (5 niveles de severidad) usando el dataset **APTOS 2019 Blindness Detection** de Kaggle. Se implementan y comparan tres arquitecturas de Deep Learning con técnicas de mejora como CLAHE, class weights, Mixup y ensamble de modelos.

## 🗂️ Estructura del Proyecto

```
1. Environment Setup & Dataset Loading
2. Exploratory Data Analysis (EDA)
3. Preprocessing & Data Augmentation
4. Baseline Models
   - EfficientNet-B4
   - DenseNet121
   - Swin Transformer-S
5. Model Fitting & Hyperparameter Tuning
6. Improvements (CLAHE + Class Weights + Mixup + Ensemble)
7. Model Evaluation & Results Analysis
8. Interpretability with Grad-CAM
9. Conclusions
```

## 📦 Dependencias

```bash
pip install torch torchvision timm grad-cam albumentations
pip install numpy pandas matplotlib seaborn opencv-python pillow scikit-learn
```

## 🗃️ Dataset

**APTOS 2019 Blindness Detection** – disponible en [Kaggle](https://www.kaggle.com/c/aptos2019-blindness-detection).

Descargar el ZIP y ubicarlo en Google Drive en la ruta:
```
/content/drive/MyDrive/aptos2019-blindness-detection.zip
```

El notebook extrae el dataset automáticamente al ejecutarse en Google Colab.

## 🚀 Uso

1. Abrir el notebook en **Google Colab** (requiere GPU, se recomienda A100/T4).
2. Ejecutar la primera celda para instalar dependencias.
3. Montar Google Drive cuando se solicite.
4. Ejecutar las celdas en orden.

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/)

## 🧠 Modelos

| Modelo | Descripción |
|---|---|
| EfficientNet-B4 | CNN eficiente con escalado compuesto |
| DenseNet121 | Red con conexiones densas entre capas |
| Swin Transformer-S | Vision Transformer con ventanas desplazadas |

## 📊 Métricas

- Accuracy, Weighted F1-Score, Cohen's Kappa
- Matriz de confusión por modelo
- Visualización con Grad-CAM

## 📁 Archivos

| Archivo | Descripción |
|---|---|
| `diabetic_retinopathy_detection.ipynb` | Notebook principal |
| `requirements.txt` | Dependencias del proyecto |
